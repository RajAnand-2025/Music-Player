let allMusic = [
  {
    name: "First Song",
    artist: "First Singer",
    img: "images/1.jpg",
    src: "songs/1.mp3",
  },
  {
    name: "Second Song",
    artist: "Second Singer",
    img: "images/2.jpg",
    src: "songs/2.mp3",
  },
  {
    name: "Third Song",
    artist: "Third Singer",
    img: "images/3.jpg",
    src: "songs/3.mp3",
  },
  {
    name: "Fourth Song",
    artist: "Fourth Singer",
    img: "images/4.jpg",
    src: "songs/4.mp3",
  },
];
